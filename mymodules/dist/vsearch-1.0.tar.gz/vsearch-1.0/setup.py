from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='Поиск для учебы по Flask',
    author='tohto',
    author_email='tohoto.bean@yandex,ru',
    url='vk.com/tohoto',
    py_modules=['vsearch'],
    )